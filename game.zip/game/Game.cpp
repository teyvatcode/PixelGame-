#include "Game.h"

#include "raylib.h"

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <optional>

static const char* kSaveHeader = "PIXELGAME_SAVE_V3";
static const char* kSaveHeaderLegacy = "PIXELGAME_SAVE_V1";
static void SpawnMonstersForLevel(Game& g);
static constexpr int kWallBreakGoldBase = 6;
static constexpr int kMonsterAggroRangeTiles = 12;
static constexpr int kMonsterShooterRangeTiles = 10;
static constexpr int kBossAoeRangeTiles = 3;
static constexpr int kBossAoeTriggerRangeTiles = kBossAoeRangeTiles * 2;
static constexpr int kBossAoeWarningMs = 620;
static constexpr int kBossAoeBlastMs = 180;

static std::filesystem::path SaveFilePath() {
    std::filesystem::path p = std::filesystem::path("output") / "savegame.txt";
    return p;
}

static bool SaveExists() {
    return std::filesystem::exists(SaveFilePath());
}

static void ClearSave() {
    std::error_code ec;
    std::filesystem::remove(SaveFilePath(), ec);
}

static bool IsBlockedByMonster(const std::vector<Monster>& ms, const IVec2& p) {
    for (const auto& m : ms) {
        if (m.alive && m.pos == p) return true;
    }
    return false;
}

static bool SaveGame(const Game& g) {
    std::error_code ec;
    std::filesystem::create_directories("output", ec);

    std::ofstream out(SaveFilePath(), std::ios::trunc);
    if (!out) return false;

    out << kSaveHeader << '\n';
    out << g.worldSeed << '\n';
    out << g.levelIndex << ' ' << g.highestClearedLevelIndex << '\n';
    out << g.player.level << ' ' << g.player.xp << ' ' << g.player.xpToNext << ' ' << g.player.hp << ' ' << g.player.maxHp << ' ' << g.player.gold
        << ' ' << g.player.facing.x << ' ' << g.player.facing.y << ' ' << g.player.mainWeapon << ' ' << g.player.offWeapon << ' '
        << g.player.bonusDamage << ' ' << g.player.bonusCritChancePct << '\n';
    out << g.arsenal.owned.size() << '\n';
    for (const auto& w : g.arsenal.owned) {
        out << w.id << ' ' << w.level << '\n';
    }

    out << g.levelExtraMonsters.size() << '\n';
    for (size_t i = 0; i < g.levelExtraMonsters.size(); i++) {
        out << g.levelExtraMonsters[i] << (i + 1 == g.levelExtraMonsters.size() ? '\n' : ' ');
    }
    return true;
}

static bool LoadGame(Game& g) {
    std::ifstream in(SaveFilePath());
    if (!in) return false;

    std::string header;
    std::getline(in, header);
    const bool isV3 = (header == kSaveHeader);
    const bool isV2 = (header == "PIXELGAME_SAVE_V2");
    const bool isLegacyV1 = (header == kSaveHeaderLegacy);
    if (!isV3 && !isLegacyV1 && header != "PIXELGAME_SAVE_V2") return false;

    std::uint32_t loadedSeed = 0;
    if (isV3) {
        if (!(in >> loadedSeed)) return false;
    } else {
        loadedSeed = static_cast<std::uint32_t>(std::random_device{}());
    }

    int loadedLevel = 0;
    int loadedHighest = -1;
    if (!(in >> loadedLevel >> loadedHighest)) return false;

    Player p{};
    if (!(in >> p.level >> p.xp >> p.xpToNext >> p.hp >> p.maxHp >> p.gold >> p.facing.x >> p.facing.y >> p.mainWeapon >> p.offWeapon)) {
        return false;
    }
    if (isV2) {
        if (!(in >> p.bonusDamage >> p.bonusCritChancePct)) return false;
    } else {
        const int earnedLevels = std::max(0, p.level - 1);
        p.bonusDamage = earnedLevels * Player::kLevelDamageGain;
        p.bonusCritChancePct = earnedLevels * Player::kLevelCritGainPct;
    }

    size_t weaponCount = 0;
    if (!(in >> weaponCount)) return false;
    Arsenal loadedArsenal;
    loadedArsenal.owned.reserve(weaponCount);
    for (size_t i = 0; i < weaponCount; i++) {
        WeaponState st;
        if (!(in >> st.id >> st.level)) return false;
        loadedArsenal.owned.push_back(st);
    }

    g.worldSeed = loadedSeed;
    g.levels = BuildDefaultLevels(g.worldSeed);
    if (g.levels.empty()) return false;

    std::vector<int> loadedExtra(static_cast<size_t>(g.levels.size()), 0);
    size_t extraCount = 0;
    if (in >> extraCount) {
        for (size_t i = 0; i < extraCount; i++) {
            int v = 0;
            if (!(in >> v)) return false;
            if (i < loadedExtra.size()) loadedExtra[i] = std::max(0, v);
        }
    }

    g.levelIndex = std::clamp(loadedLevel, 0, static_cast<int>(g.levels.size()) - 1);
    g.highestClearedLevelIndex = std::clamp(loadedHighest, -1, static_cast<int>(g.levels.size()) - 1);
    g.levelSelectCursor = std::clamp(g.levelIndex, 0, std::max(0, static_cast<int>(g.levels.size()) - 1));

    g.player = p;
    g.arsenal = loadedArsenal;
    g.levelExtraMonsters = loadedExtra;
    g.level = g.levels[static_cast<size_t>(g.levelIndex)];
    g.player.pos = g.level.spawnP;
    SpawnMonstersForLevel(g);
    g.projectiles.clear();
    g.damageTexts.clear();
    g.bossAoeMarkers.clear();
    g.combat = CombatSystem{};
    g.shop = BuildShop(g.levelIndex, g.player, g.arsenal);
    g.completedLevelIndex = -1;
    g.tick = 0;
    g.requestQuit = false;
    g.scene = Scene::ShopBetweenLevels;
    g.hasSaveData = true;

    if (!isV3) {
        g.hasSaveData = SaveGame(g);
    }
    return true;
}

static int MaxSelectableLevelIndex(const Game& g) {
    if (g.levels.empty()) return 0;
    int maxByProgress = g.highestClearedLevelIndex + 1;
    if (maxByProgress < 0) maxByProgress = 0;
    int maxIdx = std::max(maxByProgress, g.levelIndex);
    return std::clamp(maxIdx, 0, static_cast<int>(g.levels.size()) - 1);
}

static void SpawnDamageText(Game& g, IVec2 tilePos, int damage, bool critical) {
    FloatingDamageText t;
    t.posPx = Vector2{static_cast<float>(tilePos.x * g.rc.tilePx + g.rc.tilePx / 2 - 10), static_cast<float>(tilePos.y * g.rc.tilePx + 6)};
    t.damage = damage;
    t.critical = critical;
    t.ttlMs = 520;
    t.totalMs = 520;
    g.damageTexts.push_back(t);
}

static void PushDamageEventsAsText(Game& g, const std::vector<DamageEvent>& events) {
    for (const auto& e : events) {
        SpawnDamageText(g, e.pos, e.damage, e.critical);
    }
}

static void UpdateDamageTexts(Game& g, int dtMs) {
    const float dt = static_cast<float>(dtMs) / 1000.0f;
    for (auto& t : g.damageTexts) {
        t.ttlMs -= dtMs;
        t.posPx.y -= 26.0f * dt;
    }
    g.damageTexts.erase(std::remove_if(g.damageTexts.begin(), g.damageTexts.end(), [](const FloatingDamageText& t) { return t.ttlMs <= 0; }),
                        g.damageTexts.end());
}

static void EquipAsMain(Player& player, WeaponId wid) {
    if (player.mainWeapon == wid) return;

    const WeaponId oldMain = player.mainWeapon;
    if (player.offWeapon == wid) {
        player.offWeapon = oldMain;
        player.mainWeapon = wid;
        return;
    }

    player.mainWeapon = wid;
    player.offWeapon = oldMain;
}

static bool DamageWallAndReward(Game& g, IVec2 wallPos) {
    if (!g.level.IsDestructibleWall(wallPos)) return false;

    const bool broken = g.level.HitWall(wallPos);
    if (!broken) return true;

    const int reward = kWallBreakGoldBase + g.level.index / 2;
    g.player.gold += reward;
    g.msg = TextFormat("Wall broken! +%d gold.", reward);
    g.msgTimer = 80;
    g.hasSaveData = SaveGame(g);
    return true;
}

static bool TryDamageWallInFront(Game& g) {
    WeaponState* st = g.arsenal.Get(g.player.Equipped());
    if (!st) return false;

    const WeaponSpec& sp = Spec(g.player.Equipped());
    const float range = Range(sp, *st);
    const int reach = static_cast<int>(std::ceil(range));
    const IVec2 dir = g.player.facing;
    if (dir.x == 0 && dir.y == 0) return false;

    for (int step = 1; step <= reach; step++) {
        IVec2 p{g.player.pos.x + dir.x * step, g.player.pos.y + dir.y * step};
        if (!g.level.InBounds(p)) break;
        if (g.level.At(p) != Tile::Wall) continue;

        const bool hitDestructible = DamageWallAndReward(g, p);
        if (!hitDestructible) {
            g.msg = "Outer wall is unbreakable.";
            g.msgTimer = 60;
        } else if (g.msgTimer <= 0) {
            g.msg = "Wall hit.";
            g.msgTimer = 40;
        }
        return true;
    }

    return false;
}

static int CharacterVitalityCost(const Player& player) {
    int cost = 14 + (player.maxHp - 10) * 4;
    if (cost < 14) cost = 14;
    return cost;
}

static int CharacterTrainingCost(const Player& player) { return 22 + (player.level - 1) * 10; }

static bool TryUpgradeSelectedWeapon(Game& g) {
    if (g.arsenal.owned.empty()) return false;
    const int idx = std::clamp(g.shop.upgradeCursor, 0, static_cast<int>(g.arsenal.owned.size()) - 1);
    const WeaponId wid = g.arsenal.owned[static_cast<size_t>(idx)].id;
    WeaponState* st = g.arsenal.Get(wid);
    if (!st) return false;

    const int cost = UpgradeCost(Spec(wid), *st);
    if (g.player.gold < cost) {
        g.msg = "Not enough gold for weapon upgrade.";
        g.msgTimer = 120;
        return false;
    }

    g.player.gold -= cost;
    Upgrade(*st);
    g.msg = TextFormat("Upgraded %s to Lv %d.", Spec(wid).name.c_str(), st->level);
    g.msgTimer = 120;
    g.shop.upgradeFlashMs = 260;
    g.shop.upgradeFlashWeapon = wid;
    g.hasSaveData = SaveGame(g);
    return true;
}

static bool TryUpgradeCharacter(Game& g) {
    if (g.shop.characterUpgradeCursor == 0) {
        const int cost = CharacterVitalityCost(g.player);
        if (g.player.gold < cost) {
            g.msg = "Not enough gold for vitality boost.";
            g.msgTimer = 120;
            return false;
        }
        g.player.gold -= cost;
        g.player.maxHp += 2;
        g.player.hp = std::min(g.player.maxHp, g.player.hp + 2);
        g.msg = "Vitality boosted: Max HP +2.";
        g.msgTimer = 120;
        g.hasSaveData = SaveGame(g);
        return true;
    }

    const int cost = CharacterTrainingCost(g.player);
    if (g.player.gold < cost) {
        g.msg = "Not enough gold for training boost.";
        g.msgTimer = 120;
        return false;
    }
    g.player.gold -= cost;
    g.player.ApplyLevelUpGrowth();
    g.player.xp = 0;
    g.msg = TextFormat("Training boosted: Lv+1, HP+%d, DMG+%d, CRIT+%d%%.", Player::kLevelHpGain, Player::kLevelDamageGain,
                       Player::kLevelCritGainPct);
    g.msgTimer = 120;
    g.hasSaveData = SaveGame(g);
    return true;
}

static void BeginFromLogin(Game& g) {
    ClearSave();
    NewRun(g);
    g.scene = Scene::ShopBetweenLevels;
    g.shop = BuildShop(g.levelIndex, g.player, g.arsenal);
    g.msg = "New run started.";
    g.msgTimer = 180;
    g.hasSaveData = SaveGame(g);
}

static void ContinueFromLogin(Game& g) {
    if (LoadGame(g)) {
        g.msg = "Loaded save.";
        g.msgTimer = 160;
        return;
    }

    NewRun(g);
    g.scene = Scene::ShopBetweenLevels;
    g.msg = "Save load failed. Started new run.";
    g.msgTimer = 180;
    g.hasSaveData = SaveGame(g);
}

static void SpawnMonstersForLevel(Game& g) {
    g.monsters.clear();
    g.monsters.reserve(g.level.spawnM.size() + 1);
    const int levelNo = g.level.index;

    auto makeBaseMonster = [&](const IVec2& sp) {
        Monster m;
        m.pos = sp;
        m.maxHp = 2 + levelNo * 2;
        m.hp = m.maxHp;
        m.attack = 1 + levelNo / 2;
        m.attackCooldownMs = 900;
        m.goldDrop = 6 + levelNo * 3;
        m.xpDrop = 2 + levelNo;
        return m;
    };

    for (const auto& sp : g.level.spawnM) {
        g.monsters.push_back(makeBaseMonster(sp));
    }

    if (levelNo >= 6 && !g.monsters.empty()) {
        int shooterCount = std::max(1, static_cast<int>(g.monsters.size()) / 3);
        shooterCount = std::min(shooterCount, static_cast<int>(g.monsters.size()));
        for (int i = 0; i < shooterCount; i++) {
            Monster& s = g.monsters[static_cast<size_t>(i)];
            s.isShooter = true;
            s.attack += 1;
            s.attackCooldownMs = 1200;
            s.goldDrop += 4;
            s.xpDrop += 1;
        }
    }

    auto occupiedByMonster = [&](const IVec2& p) {
        for (const auto& m : g.monsters) {
            if (m.alive && m.pos == p) return true;
        }
        return false;
    };

    auto findBossSpawn = [&]() {
        for (const auto& sp : g.level.spawnM) {
            if (!occupiedByMonster(sp)) return sp;
        }

        const IVec2 aroundExit[4] = {
            {g.level.exitPos.x - 1, g.level.exitPos.y},
            {g.level.exitPos.x + 1, g.level.exitPos.y},
            {g.level.exitPos.x, g.level.exitPos.y - 1},
            {g.level.exitPos.x, g.level.exitPos.y + 1},
        };
        for (const auto& p : aroundExit) {
            if (g.level.Walkable(p) && p != g.level.spawnP && !occupiedByMonster(p)) return p;
        }

        for (int y = g.level.h - 2; y >= 1; y--) {
            for (int x = g.level.w - 2; x >= 1; x--) {
                IVec2 p{x, y};
                if (g.level.Walkable(p) && p != g.level.spawnP && p != g.level.exitPos && !occupiedByMonster(p)) return p;
            }
        }

        return g.level.spawnP;
    };

    auto makeMiniBoss = [&]() {
        Monster miniBoss = makeBaseMonster(findBossSpawn());
        miniBoss.isMiniBoss = true;
        miniBoss.isShooter = true;
        miniBoss.maxHp = miniBoss.maxHp * 3 + 10;
        miniBoss.hp = miniBoss.maxHp;
        miniBoss.attack += 2 + levelNo / 8;
        miniBoss.goldDrop = miniBoss.goldDrop * 2;
        miniBoss.xpDrop = miniBoss.xpDrop * 2;
        return miniBoss;
    };

    auto makeBoss = [&]() {
        Monster boss = makeBaseMonster(findBossSpawn());
        boss.isBoss = true;
        boss.isShooter = true;
        boss.maxHp = boss.maxHp * 5 + 20;
        boss.hp = boss.maxHp;
        boss.attack += 4 + levelNo / 5;
        boss.aoeCooldownMs = 1400;
        boss.goldDrop = boss.goldDrop * 4;
        boss.xpDrop = boss.xpDrop * 4;
        return boss;
    };

    if (levelNo % 10 == 0) {
        g.monsters.push_back(makeBoss());
    } else if (levelNo % 5 == 0) {
        g.monsters.push_back(makeMiniBoss());
    }

    // Persistent progression-driven extra monsters for this level.
    int extraCount = 0;
    if (g.levelIndex >= 0 && g.levelIndex < static_cast<int>(g.levelExtraMonsters.size())) {
        extraCount = g.levelExtraMonsters[static_cast<size_t>(g.levelIndex)];
    }
    if (extraCount > 0) {
        for (int i = 0; i < extraCount; i++) {
            bool placed = false;
            for (int attempts = 0; attempts < 200; attempts++) {
                IVec2 p{std::uniform_int_distribution<int>(1, g.level.w - 2)(g.rng), std::uniform_int_distribution<int>(1, g.level.h - 2)(g.rng)};
                if (!g.level.Walkable(p)) continue;
                if (p == g.level.spawnP || p == g.level.exitPos) continue;
                if (occupiedByMonster(p)) continue;
                g.monsters.push_back(makeBaseMonster(p));
                placed = true;
                break;
            }
            if (!placed) break;
        }
    }
}

void NewRun(Game& g) {
    g.worldSeed = static_cast<std::uint32_t>(std::random_device{}());
    g.levels = BuildDefaultLevels(g.worldSeed);
    g.levelIndex = 0;
    g.level = g.levels.empty() ? Level{} : g.levels[0];
    g.levelExtraMonsters.assign(g.levels.size(), 0);
        g.player.hp = g.player.maxHp;

    g.player = Player{};
    g.arsenal = Arsenal{};
    g.arsenal.owned.push_back(WeaponState{1, 1});
    g.arsenal.owned.push_back(WeaponState{2, 1});
    g.player.mainWeapon = 1;
    g.player.offWeapon = 2;

    LoadLevel(g, 0);
    g.scene = Scene::Login;
    g.shop = BuildShop(g.levelIndex, g.player, g.arsenal);
    g.projectiles.clear();
    g.combat = CombatSystem{};
    g.damageTexts.clear();
    g.bossAoeMarkers.clear();

    g.tick = 0;
    g.msg = "Ready.";
    g.msgTimer = 180;
    g.requestQuit = false;
    g.hasSaveData = SaveExists();
    g.completedLevelIndex = -1;
    g.highestClearedLevelIndex = -1;
    g.levelSelectCursor = 0;
    g.dashCooldownMs = 0;
    g.hitStopMs = 0;
    g.screenShakeMs = 0;
    g.screenShakePx = 0.0f;
    g.playerAttackFlashMs = 0;
    g.playerHurtFlashMs = 0;
}

void LoadLevel(Game& g, int idx) {
    g.levelIndex = idx;
    g.level = g.levels[static_cast<size_t>(idx)];
    g.player.pos = g.level.spawnP;
    SpawnMonstersForLevel(g);
    g.projectiles.clear();
    g.bossAoeMarkers.clear();
    g.goldPickupActive = false;
    g.goldPickupAmount = 0;

    // Place one gold pickup point on the path each level.
    for (int attempts = 0; attempts < 240; attempts++) {
        IVec2 p{std::uniform_int_distribution<int>(1, g.level.w - 2)(g.rng), std::uniform_int_distribution<int>(1, g.level.h - 2)(g.rng)};
        if (!g.level.Walkable(p)) continue;
        if (p == g.level.spawnP || p == g.level.exitPos) continue;
        if (IsBlockedByMonster(g.monsters, p)) continue;
        g.goldPickupPos = p;
        g.goldPickupAmount = 8 + g.level.index * 3 + std::uniform_int_distribution<int>(0, 6)(g.rng);
        g.goldPickupActive = true;
        break;
    }
    g.damageTexts.clear();

    if (g.level.index % 10 == 0) {
        g.msg = TextFormat("Level %d: MAJOR BOSS floor!", g.level.index);
        g.msgTimer = 200;
    } else if (g.level.index % 5 == 0) {
        g.msg = TextFormat("Level %d: Mini boss floor.", g.level.index);
        g.msgTimer = 180;
    }
}

static void UpdateBossAoeMarkers(Game& g, int dtMs) {
    for (auto& m : g.bossAoeMarkers) {
        if (!m.exploded) {
            m.warnMs -= dtMs;
            if (m.warnMs <= 0) {
                m.exploded = true;
                m.blastMs = kBossAoeBlastMs;

                if (Manhattan(g.player.pos, m.center) <= m.radiusTiles) {
                    g.player.hp -= m.damage;
                    g.msg = TextFormat("Boss AOE hits for %d!", m.damage);
                    g.msgTimer = 60;
                    g.playerHurtFlashMs = 120;
                    g.screenShakeMs = 120;
                    g.screenShakePx = 7.0f;

                    if (g.player.hp <= 0) {
                        g.scene = Scene::GameOver;
                        g.msg = "You died.";
                        g.msgTimer = 999999;
                    }
                }
            }
            continue;
        }

        m.blastMs -= dtMs;
    }

    g.bossAoeMarkers.erase(
        std::remove_if(g.bossAoeMarkers.begin(), g.bossAoeMarkers.end(), [](const BossAoeMarker& m) { return m.exploded && m.blastMs <= 0; }),
        g.bossAoeMarkers.end());
}

static void UpdateProjectiles(Game& g, float dt) {
    std::vector<DamageEvent> damageEvents;

    // Move and handle wall collision (in Projectile::Update).
    for (auto& p : g.projectiles) {
        if (!p.alive) continue;
        p.Update(dt, g.level, g.rc.tilePx);

        IVec2 tilePos = p.TilePos(g.rc.tilePx);
        if (!g.level.InBounds(tilePos)) {
            p.alive = false;
            continue;
        }

        if (g.level.At(tilePos) == Tile::Wall) {
            if (!p.fromEnemy) {
                (void)DamageWallAndReward(g, tilePos);
            }
            p.alive = false;
            continue;
        }

        if (p.fromEnemy) {
            if (tilePos == g.player.pos) {
                g.player.hp -= p.damage;
                g.msg = TextFormat("Hit by projectile for %d!", p.damage);
                g.msgTimer = 60;
                g.playerHurtFlashMs = 120;
                g.screenShakeMs = 80;
                g.screenShakePx = 4.0f;
                p.alive = false;
                if (g.player.hp <= 0) {
                    g.scene = Scene::GameOver;
                    g.msg = "You died.";
                    g.msgTimer = 999999;
                    break;
                }
            }
            continue;
        }

        // Monster hit check: if projectile tile equals monster tile, apply damage and destroy projectile.
        for (auto& m : g.monsters) {
            if (!p.alive) break;
            if (!m.alive) continue;
            if (m.pos == tilePos) {
                g.msg = ApplyDamageToMonster(g.player, m, p.damage, &damageEvents, p.critical);
                g.msgTimer = 90;
                p.alive = false;
            }
        }
    }

    PushDamageEventsAsText(g, damageEvents);

    g.projectiles.erase(std::remove_if(g.projectiles.begin(), g.projectiles.end(), [](const Projectile& p) { return !p.alive; }),
                        g.projectiles.end());
}

static void UpdateMonsters(Game& g, int dtMs) {
    constexpr int kMonsterAttackIntervalMs = 900;
    constexpr int kShooterAttackIntervalMs = 1150;
    constexpr int kBossShooterAttackIntervalMs = 850;
    constexpr int kBossAoeIntervalMs = 2000;
    const bool allowMove = (g.tick % 20 == 0);
    std::uniform_int_distribution<int> stepDist(0, 3);

    auto shootAtPlayer = [&](const Monster& m) {
        const float sx = static_cast<float>(m.pos.x * g.rc.tilePx + g.rc.tilePx / 2);
        const float sy = static_cast<float>(m.pos.y * g.rc.tilePx + g.rc.tilePx / 2);
        const float tx = static_cast<float>(g.player.pos.x * g.rc.tilePx + g.rc.tilePx / 2);
        const float ty = static_cast<float>(g.player.pos.y * g.rc.tilePx + g.rc.tilePx / 2);
        float dx = tx - sx;
        float dy = ty - sy;
        float len = std::sqrt(dx * dx + dy * dy);
        if (len < 0.001f) return;

        Projectile p;
        p.posPx = Vector2{sx, sy};
        p.dir = Vector2{dx / len, dy / len};
        p.speed = 340.0f;
        p.damage = std::max(1, m.attack);
        p.fromEnemy = true;
        p.startTile = m.pos;
        p.maxRangePx = static_cast<float>(kMonsterShooterRangeTiles * g.rc.tilePx);
        g.projectiles.push_back(p);
    };

    auto moveTowardPlayer = [&](const Monster& m) -> std::optional<IVec2> {
        const int dx = g.player.pos.x - m.pos.x;
        const int dy = g.player.pos.y - m.pos.y;
        if (std::abs(dx) + std::abs(dy) > kMonsterAggroRangeTiles) return std::nullopt;

        IVec2 candA = m.pos;
        IVec2 candB = m.pos;
        if (std::abs(dx) >= std::abs(dy)) {
            candA = {m.pos.x + (dx > 0 ? 1 : -1), m.pos.y};
            if (dy != 0) candB = {m.pos.x, m.pos.y + (dy > 0 ? 1 : -1)};
        } else {
            candA = {m.pos.x, m.pos.y + (dy > 0 ? 1 : -1)};
            if (dx != 0) candB = {m.pos.x + (dx > 0 ? 1 : -1), m.pos.y};
        }

        if (candA != g.player.pos && g.level.Walkable(candA) && !IsBlockedByMonster(g.monsters, candA)) return candA;
        if (candB != g.player.pos && g.level.Walkable(candB) && !IsBlockedByMonster(g.monsters, candB)) return candB;
        return std::nullopt;
    };

    for (auto& m : g.monsters) {
        if (!m.alive) continue;

        if (m.attackCooldownMs > 0) m.attackCooldownMs -= dtMs;
        if (m.attackCooldownMs < 0) m.attackCooldownMs = 0;
        if (m.aoeCooldownMs > 0) m.aoeCooldownMs -= dtMs;
        if (m.aoeCooldownMs < 0) m.aoeCooldownMs = 0;

        const int distToPlayer = Manhattan(m.pos, g.player.pos);

        if (m.isBoss && distToPlayer == 1) {
            // Continuous contact damage for boss: converted from DPS to per-frame integer damage.
            m.contactDamageAccum += m.attack * dtMs;
            const int touchDmg = m.contactDamageAccum / 1000;
            m.contactDamageAccum %= 1000;
            if (touchDmg > 0) {
                g.player.hp -= touchDmg;
                g.msg = TextFormat("Boss pressure: -%d HP", touchDmg);
                g.msgTimer = 30;
                g.playerHurtFlashMs = 90;
                g.screenShakeMs = 65;
                g.screenShakePx = 4.5f;

                if (g.player.hp <= 0) {
                    g.scene = Scene::GameOver;
                    g.msg = "You died.";
                    g.msgTimer = 999999;
                    return;
                }
            }
        } else {
            m.contactDamageAccum = 0;
        }

        if (!m.isBoss && distToPlayer == 1) {
            if (m.attackCooldownMs == 0) {
                g.player.hp -= m.attack;
                g.msg = TextFormat("Monster hits you for %d!", m.attack);
                g.msgTimer = 60;
                g.playerHurtFlashMs = 120;
                g.screenShakeMs = 100;
                g.screenShakePx = 6.0f;
                m.attackCooldownMs = kMonsterAttackIntervalMs;

                if (g.player.hp <= 0) {
                    g.scene = Scene::GameOver;
                    g.msg = "You died.";
                    g.msgTimer = 999999;
                    return;
                }
            }
            continue;
        }

        if (m.isBoss && m.aoeCooldownMs == 0 && distToPlayer <= kBossAoeTriggerRangeTiles) {
            BossAoeMarker marker;
            marker.center = m.pos;
            marker.radiusTiles = kBossAoeRangeTiles;
            marker.warnMs = kBossAoeWarningMs;
            marker.damage = std::max(2, m.attack / 2);
            g.bossAoeMarkers.push_back(marker);
            g.msg = "Boss is charging AOE!";
            g.msgTimer = 45;
            m.aoeCooldownMs = kBossAoeIntervalMs;
        }

        if (m.isShooter && Manhattan(m.pos, g.player.pos) <= kMonsterShooterRangeTiles) {
            if (m.attackCooldownMs == 0) {
                shootAtPlayer(m);
                m.attackCooldownMs = m.isBoss ? kBossShooterAttackIntervalMs : kShooterAttackIntervalMs;
            }
        }

        // Require contact time before next swing if monster re-engages later.
        if (!m.isShooter) {
            m.attackCooldownMs = kMonsterAttackIntervalMs;
        }
        if (!allowMove) continue;

        if (auto chase = moveTowardPlayer(m)) {
            m.pos = *chase;
            continue;
        }

        IVec2 cand = m.pos;
        switch (stepDist(g.rng)) {
            case 0: cand = {m.pos.x, m.pos.y - 1}; break;
            case 1: cand = {m.pos.x, m.pos.y + 1}; break;
            case 2: cand = {m.pos.x - 1, m.pos.y}; break;
            case 3: cand = {m.pos.x + 1, m.pos.y}; break;
        }
        if (cand == g.player.pos) continue;
        if (g.level.Walkable(cand) && !IsBlockedByMonster(g.monsters, cand)) {
            m.pos = cand;
        }
    }
}

void Update(Game& g, int dtMs) {
    g.tick++;
    if (g.msgTimer > 0) g.msgTimer--;
    UpdateDamageTexts(g, dtMs);
    if (g.shop.upgradeFlashMs > 0) g.shop.upgradeFlashMs -= dtMs;
    if (g.dashCooldownMs > 0) g.dashCooldownMs -= dtMs;
    if (g.hitStopMs > 0) g.hitStopMs -= dtMs;
    if (g.screenShakeMs > 0) g.screenShakeMs -= dtMs;
    if (g.playerAttackFlashMs > 0) g.playerAttackFlashMs -= dtMs;
    if (g.playerHurtFlashMs > 0) g.playerHurtFlashMs -= dtMs;

    if (g.dashCooldownMs < 0) g.dashCooldownMs = 0;
    if (g.hitStopMs < 0) g.hitStopMs = 0;
    if (g.screenShakeMs < 0) g.screenShakeMs = 0;
    if (g.playerAttackFlashMs < 0) g.playerAttackFlashMs = 0;
    if (g.playerHurtFlashMs < 0) g.playerHurtFlashMs = 0;
    if (g.shop.upgradeFlashMs < 0) g.shop.upgradeFlashMs = 0;

    if (g.scene == Scene::Login) {
        Rectangle login = {40, 190, 360, 60};
        Rectangle cont = {40, 190, 360, 60};
        Rectangle fresh = {40, 260, 360, 60};
        Rectangle quit = g.hasSaveData ? Rectangle{40, 330, 360, 60} : Rectangle{40, 270, 360, 60};
        const Vector2 m = GetMousePosition();
        if (CheckCollisionPointRec(m, quit) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            g.requestQuit = true;
            return;
        }
        if (!g.hasSaveData) {
            if (CheckCollisionPointRec(m, login) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                BeginFromLogin(g);
                return;
            }
            if (IsKeyPressed(KEY_ENTER)) {
                BeginFromLogin(g);
            }
        } else {
            if (CheckCollisionPointRec(m, cont) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                ContinueFromLogin(g);
                return;
            }
            if (CheckCollisionPointRec(m, fresh) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                BeginFromLogin(g);
                return;
            }
            if (IsKeyPressed(KEY_ENTER)) {
                ContinueFromLogin(g);
            }
        }
        return;
    }

    if (g.scene == Scene::LevelComplete) {
        Rectangle next = {40, 210, 360, 60};
        Rectangle quit = {40, 290, 360, 60};
        const Vector2 m = GetMousePosition();
        if ((CheckCollisionPointRec(m, quit) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) || IsKeyPressed(KEY_ESCAPE)) {
            g.scene = Scene::Login;
            g.msg = "Back to start.";
            g.msgTimer = 120;
            return;
        }
        if ((CheckCollisionPointRec(m, next) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) || IsKeyPressed(KEY_ENTER)) {
            const int nextIdx = g.completedLevelIndex + 1;
            if (nextIdx >= 0 && nextIdx < static_cast<int>(g.levels.size())) {
                LoadLevel(g, nextIdx);
                g.scene = Scene::ShopBetweenLevels;
                g.shop = BuildShop(g.levelIndex, g.player, g.arsenal);
                g.msg = "Next level shop.";
                g.msgTimer = 180;
                g.levelSelectCursor = nextIdx;
                g.hasSaveData = SaveGame(g);
            }
        }
        return;
    }

    if (g.scene == Scene::LevelSelect) {
        const int maxSelectable = MaxSelectableLevelIndex(g);
        g.levelSelectCursor = std::clamp(g.levelSelectCursor, 0, maxSelectable);

        if (IsKeyPressed(KEY_UP)) g.levelSelectCursor = std::max(0, g.levelSelectCursor - 1);
        if (IsKeyPressed(KEY_DOWN)) g.levelSelectCursor = std::min(maxSelectable, g.levelSelectCursor + 1);

        const Vector2 mouse = GetMousePosition();
        const bool mouseClick = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);

        const int btnW = 220;
        const int btnH = 52;
        const int pad = 16;
        Rectangle btnBack = {static_cast<float>(g.rc.screenW - pad - btnW), static_cast<float>(g.rc.screenH - pad - btnH), static_cast<float>(btnW),
                             static_cast<float>(btnH)};
        if (mouseClick && CheckCollisionPointRec(mouse, btnBack)) {
            g.scene = Scene::ShopBetweenLevels;
            g.msg = "Back to shop.";
            g.msgTimer = 90;
            g.hasSaveData = SaveGame(g);
            return;
        }

        if (mouseClick) {
            const int x = 40;
            const int y0 = 132;
            const int rowH = 42;
            if (mouse.x >= x && mouse.x <= x + 520 && mouse.y >= y0 && mouse.y < y0 + rowH * (maxSelectable + 1)) {
                int idx = static_cast<int>((mouse.y - y0) / rowH);
                g.levelSelectCursor = std::clamp(idx, 0, maxSelectable);
            }
        }

        if (IsKeyPressed(KEY_ESCAPE)) {
            g.scene = Scene::ShopBetweenLevels;
            g.msg = "Back to shop.";
            g.msgTimer = 90;
            g.hasSaveData = SaveGame(g);
            return;
        }

        if (IsKeyPressed(KEY_ENTER) || mouseClick) {
            if (mouseClick && !(mouse.x >= 40 && mouse.x <= 560 && mouse.y >= 132 && mouse.y < 132 + 42 * (maxSelectable + 1))) {
                return;
            }
            LoadLevel(g, g.levelSelectCursor);
            g.scene = Scene::Playing;
            if (g.levelSelectCursor <= g.highestClearedLevelIndex) {
                g.msg = TextFormat("Replay level %d for farming.", g.levelSelectCursor + 1);
            } else {
                g.msg = TextFormat("Entering level %d.", g.levelSelectCursor + 1);
            }
            g.msgTimer = 180;
            g.hasSaveData = SaveGame(g);
        }
        return;
    }

    if (g.scene == Scene::GameOver) {
        if (IsKeyPressed(KEY_R)) NewRun(g);
        return;
    }
    if (g.scene == Scene::Victory) {
        if (IsKeyPressed(KEY_R)) NewRun(g);
        return;
    }

    if (g.scene == Scene::ShopBetweenLevels) {
        const Vector2 mouse = GetMousePosition();
        const bool mouseClick = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);

        const int ownedX = 20;
        const int ownedY = 214;
        const int ownedRowH = 28;
        const int ownedRowW = 360;
        if (mouseClick) {
            for (int i = 0; i < static_cast<int>(g.arsenal.owned.size()); i++) {
                const auto& owned = g.arsenal.owned[static_cast<size_t>(i)];
                Rectangle row = {static_cast<float>(ownedX), static_cast<float>(ownedY + i * ownedRowH), static_cast<float>(ownedRowW), 24.0f};
                if (CheckCollisionPointRec(mouse, row)) {
                    EquipAsMain(g.player, owned.id);
                    g.msg = TextFormat("Equipped %s.", Spec(owned.id).name.c_str());
                    g.msgTimer = 100;
                    break;
                }
            }
        }

        if (!g.shop.offers.empty()) {
            if (IsKeyPressed(KEY_UP)) g.shop.cursor = std::max(0, g.shop.cursor - 1);
            if (IsKeyPressed(KEY_DOWN)) g.shop.cursor = std::min(static_cast<int>(g.shop.offers.size()) - 1, g.shop.cursor + 1);
        } else {
            g.shop.cursor = 0;
        }

        if (IsKeyPressed(KEY_ONE) && g.arsenal.Has(1)) {
            EquipAsMain(g.player, 1);
            g.msg = "Equipped Sword.";
            g.msgTimer = 100;
        }
        if (IsKeyPressed(KEY_TWO) && g.arsenal.Has(2)) {
            EquipAsMain(g.player, 2);
            g.msg = "Equipped Bow.";
            g.msgTimer = 100;
        }

        if (IsKeyPressed(KEY_U)) {
            g.scene = Scene::UpgradeMenu;
            g.shop.upgradeTab = 0;
            g.shop.upgradeCursor = std::clamp(g.shop.upgradeCursor, 0, std::max(0, static_cast<int>(g.arsenal.owned.size()) - 1));
            g.msg = "Upgrade center opened.";
            g.msgTimer = 100;
            return;
        }

        // Mouse select offer (same layout numbers as Renderer.cpp)
        if (mouseClick) {
            const int y0 = 356;
            const int rowH = 30;
            if (mouse.x >= 20 && mouse.x <= 760 && mouse.y >= y0 && mouse.y < y0 + rowH * static_cast<int>(g.shop.offers.size())) {
                int idx = static_cast<int>((mouse.y - y0) / rowH);
                idx = std::clamp(idx, 0, static_cast<int>(g.shop.offers.size()) - 1);
                g.shop.cursor = idx;
            }
        }

        // Mouse buttons: Buy + Upgrade + Start level
        const int btnW = 240;
        const int btnH = 52;
        const int pad = 16;
        Rectangle btnBuy = {static_cast<float>(g.rc.screenW - pad - btnW), static_cast<float>(g.rc.screenH - pad - btnH * 3 - 20),
                            static_cast<float>(btnW), static_cast<float>(btnH)};
        Rectangle btnUpgrade = {static_cast<float>(g.rc.screenW - pad - btnW), static_cast<float>(g.rc.screenH - pad - btnH * 2 - 10),
                                static_cast<float>(btnW), static_cast<float>(btnH)};
        Rectangle btnStart = {static_cast<float>(g.rc.screenW - pad - btnW), static_cast<float>(g.rc.screenH - pad - btnH),
                              static_cast<float>(btnW), static_cast<float>(btnH)};
        if (mouseClick && CheckCollisionPointRec(mouse, btnBuy)) {
            if (!g.shop.offers.empty() && TryPurchase(g.shop, g.player, g.arsenal, g.shop.cursor)) {
                g.msg = "Purchased!";
                g.msgTimer = 120;
                g.shop = BuildShop(g.levelIndex, g.player, g.arsenal);
                g.hasSaveData = SaveGame(g);
            } else {
                g.msg = "Not enough gold (or already owned).";
                g.msgTimer = 120;
            }
        }
        if (mouseClick && CheckCollisionPointRec(mouse, btnUpgrade)) {
            g.scene = Scene::UpgradeMenu;
            g.shop.upgradeTab = 0;
            g.shop.upgradeCursor = std::clamp(g.shop.upgradeCursor, 0, std::max(0, static_cast<int>(g.arsenal.owned.size()) - 1));
            g.msg = "Upgrade center opened.";
            g.msgTimer = 100;
            return;
        }
        if (mouseClick && CheckCollisionPointRec(mouse, btnStart)) {
            g.scene = Scene::LevelSelect;
            g.levelSelectCursor = std::clamp(g.levelIndex, 0, MaxSelectableLevelIndex(g));
            g.msg = "Choose a level to enter.";
            g.msgTimer = 180;
        }

        if (IsKeyPressed(KEY_TAB)) g.player.SwapWeapons();

        if (IsKeyPressed(KEY_ENTER)) {
            if (!g.shop.offers.empty() && TryPurchase(g.shop, g.player, g.arsenal, g.shop.cursor)) {
                g.msg = "Purchased!";
                g.msgTimer = 120;
                g.shop = BuildShop(g.levelIndex, g.player, g.arsenal);
                g.hasSaveData = SaveGame(g);
            } else {
                g.msg = "Not enough gold (or already owned). Press S to start.";
                g.msgTimer = 120;
            }
        }

        if (IsKeyPressed(KEY_S)) {
            g.scene = Scene::LevelSelect;
            g.levelSelectCursor = std::clamp(g.levelIndex, 0, MaxSelectableLevelIndex(g));
            g.msg = "Choose a level to enter.";
            g.msgTimer = 180;
        }
        return;
    }

    if (g.scene == Scene::UpgradeMenu) {
        const Vector2 mouse = GetMousePosition();
        const bool mouseClick = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);

        Rectangle tabWeapon = {24, 136, 180, 42};
        Rectangle tabCharacter = {212, 136, 220, 42};
        if (mouseClick && CheckCollisionPointRec(mouse, tabWeapon)) g.shop.upgradeTab = 0;
        if (mouseClick && CheckCollisionPointRec(mouse, tabCharacter)) g.shop.upgradeTab = 1;
        if (IsKeyPressed(KEY_Q) || IsKeyPressed(KEY_E)) g.shop.upgradeTab = 1 - g.shop.upgradeTab;

        if (g.shop.upgradeTab == 0) {
            const int rows = static_cast<int>(g.arsenal.owned.size());
            g.shop.upgradeCursor = std::clamp(g.shop.upgradeCursor, 0, std::max(0, rows - 1));
            if (rows > 0) {
                if (IsKeyPressed(KEY_UP)) g.shop.upgradeCursor = std::max(0, g.shop.upgradeCursor - 1);
                if (IsKeyPressed(KEY_DOWN)) {
                    g.shop.upgradeCursor = std::min(rows - 1, g.shop.upgradeCursor + 1);
                }
            }

            if (mouseClick) {
                const int rowY0 = 212;
                const int rowH = 48;
                if (mouse.x >= 38 && mouse.x <= 768 && mouse.y >= rowY0 && mouse.y < rowY0 + rowH * rows) {
                    int idx = static_cast<int>((mouse.y - rowY0) / rowH);
                    g.shop.upgradeCursor = std::clamp(idx, 0, std::max(0, rows - 1));
                }
            }
        } else {
            if (IsKeyPressed(KEY_UP)) g.shop.characterUpgradeCursor = std::max(0, g.shop.characterUpgradeCursor - 1);
            if (IsKeyPressed(KEY_DOWN)) g.shop.characterUpgradeCursor = std::min(1, g.shop.characterUpgradeCursor + 1);
            if (mouseClick) {
                Rectangle row0 = {38, 214, 730, 88};
                Rectangle row1 = {38, 316, 730, 88};
                if (CheckCollisionPointRec(mouse, row0)) g.shop.characterUpgradeCursor = 0;
                if (CheckCollisionPointRec(mouse, row1)) g.shop.characterUpgradeCursor = 1;
            }
        }

        const int btnW = 220;
        const int btnH = 52;
        const int pad = 16;
        Rectangle btnUpgrade = {static_cast<float>(g.rc.screenW - pad - btnW), static_cast<float>(g.rc.screenH - pad - btnH * 2 - 10),
                                static_cast<float>(btnW), static_cast<float>(btnH)};
        Rectangle btnBack = {static_cast<float>(g.rc.screenW - pad - btnW), static_cast<float>(g.rc.screenH - pad - btnH), static_cast<float>(btnW),
                             static_cast<float>(btnH)};

        if (mouseClick && CheckCollisionPointRec(mouse, btnBack)) {
            g.scene = Scene::ShopBetweenLevels;
            g.msg = "Back to shop.";
            g.msgTimer = 90;
            return;
        }
        if (mouseClick && CheckCollisionPointRec(mouse, btnUpgrade)) {
            if (g.shop.upgradeTab == 0) {
                (void)TryUpgradeSelectedWeapon(g);
            } else {
                (void)TryUpgradeCharacter(g);
            }
            return;
        }

        if (IsKeyPressed(KEY_ENTER)) {
            if (g.shop.upgradeTab == 0) {
                (void)TryUpgradeSelectedWeapon(g);
            } else {
                (void)TryUpgradeCharacter(g);
            }
        }

        if (IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_B)) {
            g.scene = Scene::ShopBetweenLevels;
            g.msg = "Back to shop.";
            g.msgTimer = 90;
        }
        return;
    }

    if (g.scene == Scene::Playing && g.hitStopMs > 0) return;

    // Playing
    UpdateCooldown(g.combat, dtMs);

    // Movement and facing (supports holding a key to repeat movement)
    auto heldDir = [&]() -> IVec2 {
        if (IsKeyDown(KEY_UP)) return {0, -1};
        if (IsKeyDown(KEY_DOWN)) return {0, 1};
        if (IsKeyDown(KEY_LEFT)) return {-1, 0};
        if (IsKeyDown(KEY_RIGHT)) return {1, 0};
        return {0, 0};
    };

    auto pressedDir = [&]() -> IVec2 {
        if (IsKeyPressed(KEY_UP)) return {0, -1};
        if (IsKeyPressed(KEY_DOWN)) return {0, 1};
        if (IsKeyPressed(KEY_LEFT)) return {-1, 0};
        if (IsKeyPressed(KEY_RIGHT)) return {1, 0};
        return {0, 0};
    };

    const IVec2 pdir = pressedDir();
    const IVec2 hdir = heldDir();

    if (g.moveRepeatTimerMs > 0) g.moveRepeatTimerMs -= dtMs;

    auto tryMove = [&](IVec2 dir) -> bool {
        if (dir.x == 0 && dir.y == 0) return false;
        g.player.facing = dir;
        IVec2 np{g.player.pos.x + dir.x, g.player.pos.y + dir.y};
        if (g.level.Walkable(np) && !IsBlockedByMonster(g.monsters, np)) {
            g.player.pos = np;
            return true;
        }
        return false;
    };

    auto tryDash = [&](IVec2 dir) -> bool {
        if (dir.x == 0 && dir.y == 0) return false;
        if (g.dashCooldownMs > 0) return false;

        g.player.facing = dir;
        IVec2 cur = g.player.pos;
        bool moved = false;
        for (int i = 0; i < 2; i++) {
            IVec2 np{cur.x + dir.x, cur.y + dir.y};
            if (!g.level.Walkable(np) || IsBlockedByMonster(g.monsters, np)) break;
            cur = np;
            moved = true;
        }
        if (moved) {
            g.player.pos = cur;
            g.dashCooldownMs = 380;
            g.playerAttackFlashMs = 70;
            g.screenShakeMs = 70;
            g.screenShakePx = 3.0f;
            g.msg = "Dash!";
            g.msgTimer = 18;
        }
        return moved;
    };

    const bool dashPressed = IsKeyPressed(KEY_LEFT_SHIFT) || IsKeyPressed(KEY_RIGHT_SHIFT);
    if (dashPressed && (hdir.x != 0 || hdir.y != 0)) {
        const bool didDash = tryDash(hdir);
        if (didDash) g.moveRepeatTimerMs = g.moveInitialDelayMs;
    } else if (pdir.x != 0 || pdir.y != 0) {
        // Immediate move on press, then start repeat timer
        (void)tryMove(pdir);
        g.moveRepeatTimerMs = g.moveInitialDelayMs;
    } else if (hdir.x != 0 || hdir.y != 0) {
        // Repeat move while held
        if (g.moveRepeatTimerMs <= 0) {
            (void)tryMove(hdir);
            g.moveRepeatTimerMs = g.moveRepeatIntervalMs;
        } else {
            // Update facing even while waiting for repeat
            g.player.facing = hdir;
        }
    } else {
        // No direction held: reset so next press feels responsive
        g.moveRepeatTimerMs = 0;
    }

    if (IsKeyPressed(KEY_TAB)) g.player.SwapWeapons();

    if (IsKeyPressed(KEY_SPACE)) {
        std::vector<DamageEvent> damageEvents;
        const WeaponId equipped = g.player.Equipped();
        const WeaponSpec& sp = Spec(equipped);
        std::string m = TryAttack(g.combat, g.player, g.arsenal, g.monsters, g.projectiles, g.rc.tilePx, &damageEvents);
        if (sp.type == WeaponType::Melee && m == "No monster in range.") {
            if (TryDamageWallInFront(g)) {
                m.clear();
                g.hitStopMs = 30;
                g.screenShakeMs = 55;
                g.screenShakePx = 2.5f;
                g.playerAttackFlashMs = 55;
            }
        }
        PushDamageEventsAsText(g, damageEvents);
        if (!m.empty()) {
            g.msg = m;
            g.msgTimer = 90;
        }
        if (m == "Hit!" || m == "Monster defeated!" || m == "AOE!") {
            g.hitStopMs = 55;
            g.screenShakeMs = 85;
            g.screenShakePx = 4.0f;
            g.playerAttackFlashMs = 80;
        } else if (m == "Shot!") {
            g.playerAttackFlashMs = 55;
        }
    }

    // Projectiles
    UpdateProjectiles(g, static_cast<float>(dtMs) / 1000.0f);

    // Boss warning zones (telegraphed AOE)
    UpdateBossAoeMarkers(g, dtMs);
    if (g.scene == Scene::GameOver) return;

    // Level pickup
    if (g.goldPickupActive && g.player.pos == g.goldPickupPos) {
        g.player.gold += g.goldPickupAmount;
        g.msg = TextFormat("Found %d gold.", g.goldPickupAmount);
        g.msgTimer = 110;
        g.goldPickupActive = false;
        g.hasSaveData = SaveGame(g);
    }

    // Monsters move in discrete ticks but attack by cooldown timer.
    UpdateMonsters(g, dtMs);

    // Exit
    if (g.player.pos == g.level.exitPos) {
        g.highestClearedLevelIndex = std::max(g.highestClearedLevelIndex, g.levelIndex);
        const int nextIdx = g.levelIndex + 1;
        if (nextIdx < static_cast<int>(g.levelExtraMonsters.size())) {
            const int add = std::uniform_int_distribution<int>(1, 2)(g.rng);
            int& extra = g.levelExtraMonsters[static_cast<size_t>(nextIdx)];
            extra = std::min(extra + add, 12);
        }
        g.hasSaveData = SaveGame(g);
        if (g.levelIndex + 1 < static_cast<int>(g.levels.size())) {
            g.completedLevelIndex = g.levelIndex;
            g.scene = Scene::LevelComplete;
            g.msg = "Level complete.";
            g.msgTimer = 999999;
        } else {
            g.scene = Scene::Victory;
            g.msg = "Victory!";
            g.msgTimer = 999999;
        }
    }
}

void Render(const Game& g) {
    if (g.scene == Scene::Login) {
        DrawLogin(g.rc, g.hasSaveData, g.msg, g.msgTimer);
        return;
    }
    if (g.scene == Scene::LevelComplete) {
        DrawLevelComplete(g.rc, g.completedLevelIndex + 1);
        return;
    }
    if (g.scene == Scene::ShopBetweenLevels) {
        DrawShop(g.player, g.arsenal, g.level, g.rc, g.shop, g.msg, g.msgTimer);
        return;
    }
    if (g.scene == Scene::UpgradeMenu) {
        DrawUpgradeMenu(g.player, g.arsenal, g.rc, g.shop, g.msg, g.msgTimer);
        return;
    }
    if (g.scene == Scene::LevelSelect) {
        DrawLevelSelect(g.rc, MaxSelectableLevelIndex(g), g.levelSelectCursor, g.highestClearedLevelIndex, g.msg, g.msgTimer);
        return;
    }

    if (g.scene == Scene::GameOver) {
        DrawGameOver(g.level);
        return;
    }

    if (g.scene == Scene::Victory) {
        DrawVictory(g.player, g.arsenal);
        return;
    }

    // Playing
    float shakeX = 0.0f;
    float shakeY = 0.0f;
    if (g.screenShakeMs > 0 && g.screenShakePx > 0.0f) {
        const float t = static_cast<float>(GetTime());
        shakeX = std::sinf(t * 95.0f) * g.screenShakePx;
        shakeY = std::cosf(t * 113.0f) * g.screenShakePx;
    }

    Camera2D cam{};
    cam.target = Vector2{0.0f, 0.0f};
    cam.offset = Vector2{shakeX, shakeY};
    cam.rotation = 0.0f;
    cam.zoom = 1.0f;

    BeginMode2D(cam);
    DrawLevel(g.level, g.rc);
    for (const auto& marker : g.bossAoeMarkers) {
        const int cx = marker.center.x * g.rc.tilePx + g.rc.tilePx / 2;
        const int cy = marker.center.y * g.rc.tilePx + g.rc.tilePx / 2;
        const float radiusPx = static_cast<float>(marker.radiusTiles * g.rc.tilePx + g.rc.tilePx / 2);

        if (!marker.exploded) {
            float t = static_cast<float>(marker.warnMs) / static_cast<float>(kBossAoeWarningMs);
            t = std::clamp(t, 0.0f, 1.0f);
            const float pulse = 1.0f + 0.08f * std::sinf(static_cast<float>(GetTime()) * 16.0f);
            DrawCircle(cx, cy, radiusPx * pulse, Fade(Color{220, 60, 60, 255}, 0.10f + (1.0f - t) * 0.18f));
            DrawCircleLines(cx, cy, radiusPx * pulse, Fade(Color{255, 120, 120, 255}, 0.90f));
        } else {
            float t = static_cast<float>(marker.blastMs) / static_cast<float>(kBossAoeBlastMs);
            t = std::clamp(t, 0.0f, 1.0f);
            DrawCircle(cx, cy, radiusPx, Fade(Color{255, 160, 70, 255}, 0.34f * t));
            DrawCircleLines(cx, cy, radiusPx, Fade(Color{255, 230, 120, 255}, 0.95f * t));
        }
    }
    DrawEntities(g.player, g.monsters, g.projectiles, g.rc, g.goldPickupActive, g.goldPickupPos);
    for (const auto& t : g.damageTexts) {
        float alpha = static_cast<float>(t.ttlMs) / static_cast<float>(t.totalMs);
        alpha = std::clamp(alpha, 0.0f, 1.0f);
        const int fontSize = t.critical ? 28 : 20;
        const int px = static_cast<int>(t.posPx.x) - (t.critical ? 4 : 0);
        const int py = static_cast<int>(t.posPx.y) - (t.critical ? 4 : 0);
        const Color color = t.critical ? Color{245, 245, 255, 255} : Color{255, 210, 120, 255};
        const char* label = TextFormat("-%d", t.damage);
        if (t.critical) {
            Color outline = Fade(Color{255, 225, 170, 255}, 0.95f * alpha);
            DrawText(label, px - 2, py, fontSize, outline);
            DrawText(label, px + 2, py, fontSize, outline);
            DrawText(label, px, py - 2, fontSize, outline);
            DrawText(label, px, py + 2, fontSize, outline);
        }
        DrawText(label, px, py, fontSize, Fade(color, 0.95f * alpha));
    }
    if (g.playerAttackFlashMs > 0) {
        const int px = g.player.pos.x * g.rc.tilePx + g.rc.tilePx / 2;
        const int py = g.player.pos.y * g.rc.tilePx + g.rc.tilePx / 2;
        const int r = g.rc.tilePx / 2 + (80 - g.playerAttackFlashMs) / 4;
        DrawCircleLines(px, py, static_cast<float>(r), Fade(Color{255, 236, 150, 255}, 0.85f));
    }
    EndMode2D();

    DrawHUD(g.player, g.arsenal, g.level, g.rc, g.msg, g.msgTimer);

    if (g.playerHurtFlashMs > 0) {
        float alpha = static_cast<float>(g.playerHurtFlashMs) / 120.0f;
        alpha = std::clamp(alpha, 0.0f, 1.0f);
        DrawRectangle(0, 0, g.rc.screenW, g.rc.screenH, Fade(Color{220, 60, 60, 255}, 0.22f * alpha));
    }
}

