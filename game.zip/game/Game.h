#pragma once

#include "Scene.h"

#include "../combat/CombatSystem.h"
#include "../economy/Arsenal.h"
#include "../economy/Shop.h"
#include "../entity/Monster.h"
#include "../entity/Player.h"
#include "../entity/Projectile.h"
#include "../render/Renderer.h"
#include "../world/Level.h"

#include <random>
#include <cstdint>
#include <string>
#include <vector>

struct FloatingDamageText {
    Vector2 posPx{};
    int damage = 0;
    bool critical = false;
    int ttlMs = 0;
    int totalMs = 0;
};

struct BossAoeMarker {
    IVec2 center{};
    int radiusTiles = 3;
    int warnMs = 0;
    int blastMs = 0;
    bool exploded = false;
    int damage = 0;
};

struct Game {
    RenderConfig rc{};

    Scene scene = Scene::ShopBetweenLevels;
    std::uint32_t worldSeed = 0;
    int levelIndex = 0;
    std::vector<Level> levels;
    Level level;

    Player player{};
    Arsenal arsenal{};
    std::vector<Monster> monsters;
    std::vector<Projectile> projectiles;
    std::vector<FloatingDamageText> damageTexts;
    std::vector<BossAoeMarker> bossAoeMarkers;
    std::vector<int> levelExtraMonsters;
    IVec2 goldPickupPos{0, 0};
    bool goldPickupActive = false;
    int goldPickupAmount = 0;

    ShopState shop{};
    CombatSystem combat{};

    std::mt19937 rng{std::random_device{}()};

    int tick = 0;
    std::string msg;
    int msgTimer = 0;

    // UI / flow
    bool requestQuit = false;
    bool hasSaveData = false;
    int completedLevelIndex = -1;
    int highestClearedLevelIndex = -1;
    int levelSelectCursor = 0;

    // Movement repeat (for holding arrow keys)
    int moveRepeatTimerMs = 0;
    int moveInitialDelayMs = 180;
    int moveRepeatIntervalMs = 65;

    // Feel / juice
    int dashCooldownMs = 0;
    int hitStopMs = 0;
    int screenShakeMs = 0;
    float screenShakePx = 0.0f;
    int playerAttackFlashMs = 0;
    int playerHurtFlashMs = 0;
};

void NewRun(Game& g);
void LoadLevel(Game& g, int idx);
void Update(Game& g, int dtMs);
void Render(const Game& g);

