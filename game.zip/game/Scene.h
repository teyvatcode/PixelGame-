#pragma once

enum class Scene {
    Login,
    ShopBetweenLevels,
    UpgradeMenu,
    LevelSelect,
    Playing,
    LevelComplete,
    GameOver,
    Victory,
};

