#pragma once

#include "../economy/Arsenal.h"
#include "../entity/Monster.h"
#include "../entity/Player.h"
#include "../entity/Projectile.h"
#include "../world/Level.h"

#include <string>
#include <vector>

struct CombatSystem {
    int playerCooldownMs = 0;
};

struct DamageEvent {
    IVec2 pos{};
    int damage = 0;
    bool critical = false;
};

void UpdateCooldown(CombatSystem& c, int dtMs);

// Returns a short message for UI (can be empty).
std::string TryAttack(CombatSystem& c, Player& player, Arsenal& arsenal, std::vector<Monster>& monsters, std::vector<Projectile>& projectiles,
                      int tileSizePx, std::vector<DamageEvent>* damageEvents = nullptr);

// Applies monster death rewards (gold/xp).
std::string ApplyDamageToMonster(Player& player, Monster& m, int dmg, std::vector<DamageEvent>* damageEvents = nullptr, bool critical = false);

