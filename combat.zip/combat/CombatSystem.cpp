#include "CombatSystem.h"

#include "../core/Types.h"

#include <cmath>
#include <optional>
#include <random>

void UpdateCooldown(CombatSystem& c, int dtMs) {
    if (c.playerCooldownMs > 0) c.playerCooldownMs -= dtMs;
    if (c.playerCooldownMs < 0) c.playerCooldownMs = 0;
}

static std::optional<size_t> FindClosestMonsterInRange(const Player& player, const std::vector<Monster>& monsters, float range) {
    std::optional<size_t> best;
    int bestD = 9999;
    for (size_t i = 0; i < monsters.size(); i++) {
        if (!monsters[i].alive) continue;
        int d = Manhattan(player.pos, monsters[i].pos);
        if (d >= 1 && static_cast<float>(d) <= range && d < bestD) {
            best = i;
            bestD = d;
        }
    }
    return best;
}

static std::optional<size_t> FindClosestAliveMonster(const Player& player, const std::vector<Monster>& monsters) {
    std::optional<size_t> best;
    int bestD = 9999;
    for (size_t i = 0; i < monsters.size(); i++) {
        if (!monsters[i].alive) continue;
        int d = Manhattan(player.pos, monsters[i].pos);
        if (d < bestD) {
            best = i;
            bestD = d;
        }
    }
    return best;
}


static bool RollCritical(int critChancePct) {
    static std::mt19937 rng{std::random_device{}()};
    std::uniform_int_distribution<int> dist(1, 100);
    return dist(rng) <= critChancePct;
}

// 返回暴击倍数（无暴击返回1.0，暴击返回2.0/2.5/3.0，2.5概率最大）
static float GetCriticalMultiplier(bool critical) {
    if (!critical) return 1.0f;
    static std::mt19937 rng{std::random_device{}()};
    // 2.5倍概率最大，2/2.5/3概率分别为20%/60%/20%
    std::uniform_int_distribution<int> dist(1, 100);
    int roll = dist(rng);
    if (roll <= 20) return 2.0f;
    if (roll <= 80) return 2.5f;
    return 3.0f;
}

std::string ApplyDamageToMonster(Player& player, Monster& m, int dmg, std::vector<DamageEvent>* damageEvents, bool critical) {
    if (damageEvents) {
        damageEvents->push_back(DamageEvent{m.pos, dmg, critical});
    }
    m.hp -= dmg;
    if (m.hp > 0) return "Hit!";
    m.alive = false;
    player.gold += m.goldDrop;
    player.GainXP(m.xpDrop);
    return "Monster defeated!";
}

std::string TryAttack(CombatSystem& c, Player& player, Arsenal& arsenal, std::vector<Monster>& monsters, std::vector<Projectile>& projectiles,
                      int tileSizePx, std::vector<DamageEvent>* damageEvents) {
    WeaponId wid = player.Equipped();
    const WeaponSpec& sp = Spec(wid);
    WeaponState* st = arsenal.Get(wid);
    if (!st) return "No weapon.";

    if (c.playerCooldownMs > 0) return "";

    const int baseDmg = Damage(sp, *st) + player.bonusDamage;
    int totalCritChancePct = sp.critChancePct + player.bonusCritChancePct;
    if (totalCritChancePct < 0) totalCritChancePct = 0;
    if (totalCritChancePct > 100) totalCritChancePct = 100;
    const float range = Range(sp, *st);
    c.playerCooldownMs = CooldownMs(sp, *st);


    if (sp.type == WeaponType::Melee) {
        auto idx = FindClosestMonsterInRange(player, monsters, range);
        if (!idx) return "No monster in range.";
        const bool critical = RollCritical(totalCritChancePct);
        float critMul = GetCriticalMultiplier(critical);
        const int dmg = static_cast<int>(std::round(baseDmg * critMul));
        return ApplyDamageToMonster(player, monsters[*idx], dmg, damageEvents, critical);
    }


    if (sp.type == WeaponType::Ranged) {
        auto idx = FindClosestAliveMonster(player, monsters);

        const bool critical = RollCritical(totalCritChancePct);
        float critMul = GetCriticalMultiplier(critical);
        const int dmg = static_cast<int>(std::round(baseDmg * critMul));

        const float sx = static_cast<float>(player.pos.x * tileSizePx + tileSizePx / 2);
        const float sy = static_cast<float>(player.pos.y * tileSizePx + tileSizePx / 2);

        float dx = 0.0f;
        float dy = 0.0f;
        if (idx) {
            const Monster& target = monsters[*idx];
            const float tx = static_cast<float>(target.pos.x * tileSizePx + tileSizePx / 2);
            const float ty = static_cast<float>(target.pos.y * tileSizePx + tileSizePx / 2);
            dx = tx - sx;
            dy = ty - sy;
        } else {
            dx = static_cast<float>(player.facing.x);
            dy = static_cast<float>(player.facing.y);
        }

        float len = std::sqrt(dx * dx + dy * dy);
        if (len < 0.001f) {
            dx = 0.0f;
            dy = 1.0f;
            len = 1.0f;
        }
        const Vector2 dir = {dx / len, dy / len};

        Projectile p;
        // Spawn at player center (pixel)
        p.posPx = Vector2{sx, sy};
        p.dir = dir;
        p.speed = sp.projectileSpeed;
        p.damage = dmg;
        p.critical = critical;
        p.startTile = player.pos;
        p.maxRangePx = range * static_cast<float>(tileSizePx);
        projectiles.push_back(p);
        return "Shot!";
    }

    // 炸弹武器逻辑
    if (wid == 3) {
        // 炸弹投掷方向与人物一致
        IVec2 dir = player.facing;
        if (dir.x == 0 && dir.y == 0) dir = {0, 1};
        IVec2 bombTarget = player.pos;
        bombTarget.x += dir.x * 2;
        bombTarget.y += dir.y * 2;
        // 伤害范围1.5，穿墙
        int hit = 0;
        for (auto& m : monsters) {
            if (!m.alive) continue;
            float dist = std::sqrt(float((m.pos.x - bombTarget.x) * (m.pos.x - bombTarget.x) + (m.pos.y - bombTarget.y) * (m.pos.y - bombTarget.y)));
            if (dist <= 1.5f) {
                const bool critical = RollCritical(totalCritChancePct);
                float critMul = GetCriticalMultiplier(critical);
                const int dmg = static_cast<int>(std::round(baseDmg * critMul));
                ApplyDamageToMonster(player, m, dmg, damageEvents, critical);
                hit++;
            }
        }
        return hit > 0 ? "Bomb!" : "No monster in range.";
    }
    // 其他AOE武器
    int hit = 0;
    for (auto& m : monsters) {
        if (!m.alive) continue;
        if (Manhattan(player.pos, m.pos) <= range) {
            const bool critical = RollCritical(totalCritChancePct);
            float critMul = GetCriticalMultiplier(critical);
            const int dmg = static_cast<int>(std::round(baseDmg * critMul));
            ApplyDamageToMonster(player, m, dmg, damageEvents, critical);
            hit++;
        }
    }
    return hit > 0 ? "AOE!" : "No monster in range.";
}

