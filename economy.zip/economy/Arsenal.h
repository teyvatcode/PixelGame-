#pragma once

#include "Weapon.h"

#include <vector>

struct Arsenal {
    std::vector<WeaponState> owned;

    bool Has(WeaponId id) const;
    WeaponState* Get(WeaponId id);
    const WeaponState* Get(WeaponId id) const;
};

const WeaponSpec& Spec(WeaponId id);
std::vector<WeaponSpec> BuildDefaultWeaponTable();

