#include "Weapon.h"

int Damage(const WeaponSpec& spec, const WeaponState& st) {
    return spec.baseDamage + (st.level - 1);
}

float Range(const WeaponSpec& spec, const WeaponState& st) {
    if (spec.id == 2) {
        return spec.baseRange + 0.25f * static_cast<float>(st.level - 1);
    }

    float r = spec.baseRange;
    // small growth every 3 levels
    r += static_cast<float>((st.level - 1) / 3);
    return r;
}

int CooldownMs(const WeaponSpec& spec, const WeaponState& st) {
    // slightly faster as weapon levels up (bounded)
    int cd = spec.baseCooldownMs - (st.level - 1) * 10;
    if (cd < 80) cd = 80;
    return cd;
}

int UpgradeCost(const WeaponSpec& spec, const WeaponState& st) {
    (void)spec;
    // quadratic scaling
    return 10 * st.level * st.level;
}

void Upgrade(WeaponState& st) { st.level += 1; }

