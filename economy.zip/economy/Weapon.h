#pragma once

#include <string>

enum class WeaponType { Melee, Ranged, Aoe };
using WeaponId = int;

struct WeaponSpec {
    WeaponId id{};
    std::string name;
    WeaponType type = WeaponType::Melee;

    int baseDamage = 1;
    float baseRange = 1.0f;
    int baseCooldownMs = 250;
    float projectileSpeed = 0.0f;  // only for ranged
    int critChancePct = 0;

    int buyCost = 0;
};

struct WeaponState {
    WeaponId id{};
    int level = 1;
};

int Damage(const WeaponSpec& spec, const WeaponState& st);
float Range(const WeaponSpec& spec, const WeaponState& st);
int CooldownMs(const WeaponSpec& spec, const WeaponState& st);
int UpgradeCost(const WeaponSpec& spec, const WeaponState& st);
void Upgrade(WeaponState& st);

