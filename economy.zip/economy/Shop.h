#pragma once

#include "Arsenal.h"

#include "../entity/Player.h"

#include <vector>

struct ShopOffer {
    enum class Kind { BuyWeapon, UpgradeWeapon } kind = Kind::UpgradeWeapon;
    WeaponId wid{};
    int price{};
};

struct ShopState {
    std::vector<ShopOffer> offers;
    int cursor = 0;
    bool showUpgradePanel = false;
    int upgradeCursor = 0;
    int upgradeTab = 0;  // 0: weapon, 1: character
    int characterUpgradeCursor = 0;
    int upgradeFlashMs = 0;
    WeaponId upgradeFlashWeapon = 0;
};

ShopState BuildShop(int levelIndex, const Player& player, const Arsenal& arsenal);
bool TryPurchase(ShopState& shop, Player& player, Arsenal& arsenal, int offerIndex);

