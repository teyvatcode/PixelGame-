#include "Arsenal.h"

#include <stdexcept>

bool Arsenal::Has(WeaponId id) const { return Get(id) != nullptr; }

WeaponState* Arsenal::Get(WeaponId id) {
    for (auto& w : owned) {
        if (w.id == id) return &w;
    }
    return nullptr;
}

const WeaponState* Arsenal::Get(WeaponId id) const {
    for (const auto& w : owned) {
        if (w.id == id) return &w;
    }
    return nullptr;
}

std::vector<WeaponSpec> BuildDefaultWeaponTable() {
    // Keep ids stable.
    std::vector<WeaponSpec> t;
    t.push_back(WeaponSpec{1, "Sword", WeaponType::Melee, 2, 1.0f, 250, 0.0f, 14, 0});
    t.push_back(WeaponSpec{2, "Bow", WeaponType::Ranged, 1, 1.0f, 300, 520.0f, 22, 40});
    t.push_back(WeaponSpec{3, "Bomb", WeaponType::Aoe, 3, 4.0f, 600, 0.0f, 0, 100});
    return t;
}

const WeaponSpec& Spec(WeaponId id) {
    static std::vector<WeaponSpec> table = BuildDefaultWeaponTable();
    for (const auto& s : table) {
        if (s.id == id) return s;
    }
    throw std::runtime_error("Unknown weapon id");
}

