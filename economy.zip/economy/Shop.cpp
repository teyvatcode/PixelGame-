#include "Shop.h"

#include "Weapon.h"

ShopState BuildShop(int levelIndex, const Player& player, const Arsenal& arsenal) {
    (void)player;
    ShopState s;

    // Offer: buy one new weapon gradually by level
    // Level 1+: Bow, Level 2+: Staff
    if (levelIndex >= 0 && !arsenal.Has(2)) {
        s.offers.push_back(ShopOffer{ShopOffer::Kind::BuyWeapon, 2, Spec(2).buyCost});
    }
    if (levelIndex >= 1 && !arsenal.Has(3)) {
        s.offers.push_back(ShopOffer{ShopOffer::Kind::BuyWeapon, 3, Spec(3).buyCost});
    }

    return s;
}

bool TryPurchase(ShopState& shop, Player& player, Arsenal& arsenal, int offerIndex) {
    if (offerIndex < 0 || offerIndex >= static_cast<int>(shop.offers.size())) return false;
    const ShopOffer& o = shop.offers[static_cast<size_t>(offerIndex)];
    if (player.gold < o.price) return false;

    if (o.kind == ShopOffer::Kind::BuyWeapon) {
        if (!arsenal.Has(o.wid)) {
            player.gold -= o.price;
            arsenal.owned.push_back(WeaponState{o.wid, 1});

            // Auto-equip to offhand if empty
            if (player.offWeapon == 0) player.offWeapon = o.wid;
            return true;
        }
        return false;
    }

    if (o.kind == ShopOffer::Kind::UpgradeWeapon) {
        WeaponState* st = arsenal.Get(o.wid);
        if (!st) return false;
        const WeaponSpec& sp = Spec(o.wid);
        const int cost = UpgradeCost(sp, *st);
        if (player.gold < cost) return false;
        player.gold -= cost;
        Upgrade(*st);
        return true;
    }

    return false;
}

