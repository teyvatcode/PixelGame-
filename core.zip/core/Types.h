#pragma once

#include <cstdlib>

struct IVec2 {
    int x{};
    int y{};
};

inline bool operator==(const IVec2& a, const IVec2& b) { return a.x == b.x && a.y == b.y; }
inline bool operator!=(const IVec2& a, const IVec2& b) { return !(a == b); }

inline int Manhattan(const IVec2& a, const IVec2& b) { return std::abs(a.x - b.x) + std::abs(a.y - b.y); }

