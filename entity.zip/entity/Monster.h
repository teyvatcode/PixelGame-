#pragma once

#include "../core/Types.h"

struct Monster {
    IVec2 pos{};
    int hp = 3;
    int maxHp = 3;
    int attack = 1;
    int attackCooldownMs = 900;
    int aoeCooldownMs = 0;
    int contactDamageAccum = 0;
    int goldDrop = 5;
    int xpDrop = 2;
    bool isShooter = false;
    bool isMiniBoss = false;
    bool isBoss = false;
    bool alive = true;
};

