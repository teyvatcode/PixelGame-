#include "Player.h"

void Player::ApplyLevelUpGrowth() {
    level += 1;
    xpToNext = static_cast<int>(xpToNext * 1.35f) + 1;
    maxHp += kLevelHpGain;
    hp = maxHp;
    bonusDamage += kLevelDamageGain;
    bonusCritChancePct += kLevelCritGainPct;
}

void Player::GainXP(int amount) {
    xp += amount;
    while (xp >= xpToNext) {
        xp -= xpToNext;
        ApplyLevelUpGrowth();
    }
}

void Player::SwapWeapons() {
    if (offWeapon == 0) return;
    WeaponId tmp = mainWeapon;
    mainWeapon = offWeapon;
    offWeapon = tmp;
}

