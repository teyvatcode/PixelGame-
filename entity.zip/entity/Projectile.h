#pragma once

#include "../core/Types.h"
#include "../world/Level.h"

#include "raylib.h"

struct Projectile {
    Vector2 posPx{};
    Vector2 dir{0.0f, 1.0f};
    float speed = 500.0f;
    int damage = 1;
    bool critical = false;
    bool fromEnemy = false;
    IVec2 startTile{0, 0};
    float maxRangePx = 6.0f;
    float traveledPx = 0.0f;
    bool alive = true;

    IVec2 TilePos(int tileSizePx) const;
    void Update(float dt, const Level& level, int tileSizePx);
};

