#include "Projectile.h"

IVec2 Projectile::TilePos(int tileSizePx) const {
    return IVec2{
        static_cast<int>(posPx.x) / tileSizePx,
        static_cast<int>(posPx.y) / tileSizePx,
    };
}

void Projectile::Update(float dt, const Level& level, int tileSizePx) {
    if (!alive) return;

    const float step = speed * dt;
    posPx.x += dir.x * speed * dt;
    posPx.y += dir.y * speed * dt;
    traveledPx += step;

    // Convert to tile and check bounds.
    IVec2 tilePos = TilePos(tileSizePx);

    if (!level.InBounds(tilePos)) {
        alive = false;
        return;
    }

    if (traveledPx > maxRangePx) {
        alive = false;
        return;
    }
}

