#pragma once

#include "../core/Types.h"
#include "../economy/Weapon.h"

struct Player {
    static constexpr int kLevelHpGain = 2;
    static constexpr int kLevelDamageGain = 1;
    static constexpr int kLevelCritGainPct = 2;

    IVec2 pos{};
    IVec2 facing{0, 1};

    int level = 1;
    int xp = 0;
    int xpToNext = 5;

    int hp = 10;
    int maxHp = 10;
    int bonusDamage = 0;
    int bonusCritChancePct = 0;

    int gold = 0;

    // 0 means empty slot
    WeaponId mainWeapon = 1;  // default Sword
    WeaponId offWeapon = 0;

    void GainXP(int amount);
    void ApplyLevelUpGrowth();
    WeaponId Equipped() const { return mainWeapon; }
    void SwapWeapons();
};

